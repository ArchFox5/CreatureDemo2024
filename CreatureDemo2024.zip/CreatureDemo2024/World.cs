﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static CreatureDemo2024.Library;

namespace CreatureDemo2024
{
    public class World
    {
        List<Location> locations = new List<Location>();
        List<Creature> creatures = new List<Creature>();
      
        public World()
        {
            locations.Add(
                new Location() {
                    Name = "Tundra", 
                    Description = "Polar bear in a snow storm.", 
                    Type = LocationType.Tundra,
                    Creatures = new List<Creature>
                    {
                        new Creature()
                        {
                            Name = "Bob",
                            CutenessType = Cuteness.UglyCute,
                            NumberOfLegs = 2,

                        }
                    }
                    
                }
                );
            locations.Add(
               new Location()
               {
                   Name = "Desert",
                   Description = "Super dry air, lot's of beach flooring?",
                   Type = LocationType.Tundra
               }
               );
            locations.Add(
               new Location()
               {
                   Name = "Sea",
                   Description = "Swimmy Swimmy Wet and Dimmy",
                   Type = LocationType.Tundra
               }
               );
        }


        public string ShowLocations()
        {
            string output = "";
            foreach(Location location in locations)
            {
                output += $"{location.Name} \n {location.Description} \n";
            }

            return output;
        }

        public void Travel()
        {
            Print("1. Tundra, 2. Desert, 3. Sea") 
            Console.ReadLine();

            if (Console.ReadLine = "1")
            {

            }

            else (

        }

    }
}