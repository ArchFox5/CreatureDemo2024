﻿using static CreatureDemo2024.Library;

namespace CreatureDemo2024
{
    internal class Menu
    {
        public void LoadMenu()
        {
            World world = new World();
            //world.ShowLocations();
            Print(world.ShowLocations());
            Print("Where do you want to go?");
        }
    }
}
