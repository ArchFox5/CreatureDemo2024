﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CreatureDemo2024
{
    internal class EasternDragon: Flying
    {
        public override string Vocalize()
        {
            //base.Vocalize();
            return $"{Name} goes waawwaweeeweaasww.";
        }
    }
}