﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CreatureDemo2024
{

    public enum LocationType
    {
        Tundra,
        Rainforest,
        Desert,
        Tropical,
        Sea,
        Cave
    }
    public class Location
    {
        public string Name;
        public string Description;
        public LocationType Type = LocationType.Tundra;
    }

}