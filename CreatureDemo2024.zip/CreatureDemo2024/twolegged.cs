﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CreatureDemo2024
{
    internal class twolegged : Creature, ICraft
    {
        void ICraft.Craft()
        {
            //this is where the crafting statements would be
        }
    }
}

/*
Konig checked his watch. Worn leather barely hanging off of his thick wrist as he pointed it twards the desk again. Something about today's meeting was especially boring.
he blinked away his lack of sleep, blue eyes tracking idle movements of his Coworkers. Course his 2nd in command was always the most intersting. 
 
 
 
 */