﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreatureDemo2024
{
    internal interface ICraft
    {
        void Craft();


    }
}
