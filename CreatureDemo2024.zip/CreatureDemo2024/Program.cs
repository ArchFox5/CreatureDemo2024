﻿
using CreatureDemo2024;

namespace CreatureDemo2024
{
    internal class Program
    {
        static void Main()
        {
            Menu menu = new Menu();
            menu.LoadMenu();

            new Menu (Command).LoadMenu();
        }
    }
}
