﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreatureDemo2024
{
    internal class Library
    {
        //declare delegate and set up signature
        public delegate void PrintPlatform(string output);
        //instance of the delegate and which method it it acting on behalf of
        public static PrintPlatform Print = PrintConsole;

        //Platform specific method
        public static void PrintConsole(string output)
        {
            Console.WriteLine(output);
        }

        public static void PrintWeb(string output)
        {

        }
    }
}
