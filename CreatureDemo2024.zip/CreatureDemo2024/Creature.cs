﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CreatureDemo2024
{
    public enum Cuteness
    {
        ScaryCute,
        SweetCute,
        ExtraCute,
        Cuddly,
        UglyCute
    }

    public class Creature
    {
        

        public string Name;
        public int NumberOfLegs;
        public List<Item> Diet = new List<Item>();
        public Cuteness CutenessType = Cuteness.UglyCute;
        

        public void Swim() { }
        public void Eat(Item item) { }
        public void Move() { }
        public virtual string Vocalize ()
        {
            return $"{Name} vocalizes";
        }

        

    }
}